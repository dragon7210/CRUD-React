const inputData = [
  {
    id: 1,
    name: "Fisc1",
    fiscal: "2022",
    type: "Plan1",
  },
  { id: 2, name: "Fisc2", fiscal: "2022", type: "Plan2" },
  { id: 3, name: "Fisc3", fiscal: "2023", type: "Plan3" },
  { id: 4, name: "Fisc4", fiscal: "2024", type: "Plan4" },
  { id: 5, name: "Fisc5", fiscal: "2025", type: "Plan5" },
  { id: 6, name: "Fisc6", fiscal: "2026", type: "Plan6" },
  { id: 7, name: "Fisc7", fiscal: "2027", type: "Plan7" },
];

export default inputData;
